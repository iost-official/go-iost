# -*- coding:utf-8 -*-
from multiprocessing import Pool
import os
import time
#import commands
rangeNum = 25
poolNum =200
startNum = 0
def run_loop(num):
    start = time.clock()
    for k in range(rangeNum):
        #print(str(num))
        trNum = str(num*rangeNum+k+startNum)
        #print("trNum:"+trNum)
        os.system("./iwallet compile -n "+str(trNum)+" sc/1to2.lua -d sc/1to2-"+str(trNum)+".sc")
        os.system("./iwallet -s 52.60.163.60:30303 publish sc/1to2-"+str(trNum)+".sc -k sc/server1_secp")
        #os.system("./iwallet publish sc/1to2-"+str(trNum)+".sc -k sc/server1_secp")

        #x=retMsg.splitlines()
        #if x[0]!="ok":
        #    print("Error publish")
        #time.sleep(0.02)

        #os.system("./iwallet compile sc/2to3.lua")
        #os.system("./iwallet publish sc/2to3.sc -k sc/server2_secp")
        #time.sleep(0.02)

        #os.system("./iwallet compile sc/3to1.lua")
        #os.system("./iwallet publish sc/3to1.sc -k sc/server3_secp")
        #time.sleep(0.02)
    end = time.clock()
    print(end-start)

if __name__ == "__main__":
    p = Pool(poolNum)
    for i in range(poolNum):
        p.apply_async(run_loop, args=(i,))
    print("Waiting for all subprocesses done...")
    p.close()
    p.join()
    print("All subprocesses done.")

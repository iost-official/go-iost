--- main 合约主入口
-- server2转账server3
-- @gas_limit 10000
-- @gas_price 0.001
-- @param_cnt 0
-- @return_cnt 0
function main()
	Transfer("s1oUQNTcRKL7uqJ1aRqUMzkAkgqJdsBB7uW9xrTd85qB","2BibFrAhc57FAd3sDJFbPqjwskBJb5zPDtecPWVRJ1jxT",100)
end
